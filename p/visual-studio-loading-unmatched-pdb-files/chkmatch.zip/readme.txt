
ChkMatch 1.0.3
Copyright (C) Oleg Starodumov 2004
http://www.debuginfo.com/

How to get help and usage instructions
--------------------------------------

chkmatch -?


More information
----------------

http://www.debuginfo.com/tools/chkmatch.html


Terms of use
------------

This software is provided "as-is", without any express 
or implied warranty. In no event will the authors be held 
liable for any damages arising from the use of this software. 

You may not distribute ChkMatch in any form without express 
written permission of Oleg Starodumov. 

